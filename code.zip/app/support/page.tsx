"use client"

import React from "react"

import Header from "@/components/header"
import Footer from "@/components/footer"
import { ChevronDown } from "lucide-react"

export default function Support() {
  const [expandedFaq, setExpandedFaq] = React.useState<number | null>(null)

  const faqs = [
    {
      q: "GFI Ride는 어떤 앱인가요?",
      a: "GFI Ride는 AI 코칭, 소셜 라이딩, 게이미피케이션 기능을 제공하는 한국 라이더 맞춤형 자전거 앱입니다.",
    },
    {
      q: "비용이 얼마인가요?",
      a: "기본 기능은 무료로 제공되며, 프리미엄 기능은 구독으로 이용 가능합니다.",
    },
    {
      q: "어디에서 다운로드할 수 있나요?",
      a: "Google Play Store와 Apple App Store에서 GFI Ride를 검색하여 다운로드할 수 있습니다.",
    },
    {
      q: "낙상 감지 기능은 안전한가요?",
      a: "네, 낙상 감지 기능은 센서 데이터를 기반으로 돌발 상황을 감지하고 비상 연락망에 자동으로 알립니다.",
    },
    {
      q: "내 데이터는 안전하게 보호되나요?",
      a: "개인정보보호법에 따라 사용자 데이터는 암호화되어 안전하게 보호됩니다.",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-24">
        {/* Header Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-20 max-w-6xl mx-auto">
          <h1 className="text-4xl sm:text-5xl font-bold mb-6 text-balance font-serif">고객 지원</h1>
          <h2 className="text-2xl mb-4 text-balance font-serif text-primary font-bold sm:text-4xl">궁금한 점이 있으신가요?</h2>
          <p className="text-lg text-muted-foreground max-w-3xl font-serif">언제든지 GFI 팀에 문의해주세요.</p>
        </section>

        {/* FAQ Section */}
        

        {/* Contact Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-16 max-w-6xl mx-auto">
          <h3 className="text-3xl font-bold mb-12 font-serif">Contact Us</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-card rounded-lg p-8 border border-border">
              <h4 className="text-2xl font-bold mb-6 font-serif">연락처</h4>
              <div className="space-y-4">
                <div className="font-serif">
                  <p className="text-muted-foreground mb-1 font-serif">이메일</p>
                  <p className="text-foreground font-semibold font-serif">team_gfi@gmail.com</p>
                </div>
                <div>
                  <p className="text-muted-foreground mb-1 font-serif">회사 주소</p>
                  <p className="text-foreground font-serif">{"강원도 원주시 흥업면 남원로 20-10"}</p>
                </div>
              </div>
            </div>
            <div className="bg-card rounded-lg p-8 border border-border">
              <h4 className="text-2xl font-bold mb-6 font-serif">문의 양식</h4>
              <form className="space-y-4">
                <input
                  type="text"
                  placeholder="이름"
                  className="w-full bg-background border border-border rounded-lg px-4 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary font-serif"
                />
                <input
                  type="email"
                  placeholder="이메일"
                  className="w-full bg-background border border-border rounded-lg px-4 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary font-serif"
                />
                <textarea
                  placeholder="문의 내용"
                  rows={4}
                  className="w-full bg-background border border-border rounded-lg px-4 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary font-serif"
                />
                <button
                  type="submit"
                  className="w-full bg-primary text-primary-foreground font-bold py-2 rounded-lg hover:bg-opacity-90 transition-all font-serif"
                >
                  전송
                </button>
              </form>
            </div>
          </div>
        </section>

        {/* Social Media Section */}
        
      </main>
      <Footer />
    </div>
  )
}
