import Header from "@/components/header"
import Footer from "@/components/footer"
import { Heart, Users, Trophy, AlertCircle, Navigation } from "lucide-react"

const features = [
  {
    id: 1,
    title: "AI 코스 추천 및 네비게이션",
    description: "선호도(경관, 난이도)를 반영한 AI 맞춤 코스 추천. 초행길도 문제없는 스마트 네비게이션.",
    icon: Navigation,
    imageUrl:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gemini_Generated_Image_rlsxn2rlsxn2rlsx-IyuWgvvS3qYhLFqqgrUBWAgJpnbm8s.png",
  },
  {
    id: 2,
    title: "AI 건강 코칭 및 데이터 분석",
    description: "라이딩 데이터 기반 개인별 맞춤 건강 코칭. 상세한 데이터 분석 리포트.",
    icon: Heart,
    imageUrl:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gemini_Generated_Image_1sst0g1sst0g1sst-UDgkYpWlmESNe4uxFZu6zScs9Tx2NV.png",
  },
  {
    id: 3,
    title: "실시간 그룹 라이딩 및 소셜",
    description: "친구들과 실시간 위치 공유, 그룹 채팅. 라이딩 중에도 끊김 없는 소통.",
    icon: Users,
    imageUrl:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gemini_Generated_Image_yjllmoyjllmoyjll-iQOhGOEqYCrwMJQWmEOaVHYmz2BYiz.png",
  },
  {
    id: 4,
    title: "게이미피케이션 및 리워드",
    description: "레벨업, 챌린지, 시즌 배지로 라이딩의 재미를 더하고 성취감 획득.",
    icon: Trophy,
    imageUrl:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gemini_Generated_Image_shnj7cshnj7cshnj-MoenFNeD8wFJ4d7psVItZeDhHOwOpw.png",
  },
  {
    id: 5,
    title: "안전 기능",
    description: "돌발 상황 감지 및 비상 연락망 알림. 라이더들이 공유하는 위험 구간 정보.",
    icon: AlertCircle,
    imageUrl:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Gemini_Generated_Image_q4j35dq4j35dq4j3-QjrkHsEKFnGtL4UPLWOCu8710LUnYD.png",
  },
]

export default function Features() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-24">
        {/* Header Section */}
        <section className="px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto py-9">
          <h1 className="text-4xl sm:text-5xl font-bold mb-6 text-balance font-serif">주요 기능</h1>
          <h2 className="text-2xl sm:text-3xl mb-4 text-balance font-serif text-primary font-bold">
            GFI Ride의 스마트하고 강력한 기능들.
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl font-serif">
            당신의 라이딩을 한 단계 업그레이드할 APEX 솔루션.
          </p>
        </section>

        {/* Features Grid */}
        <section className="px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto py-1">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature) => {
              const Icon = feature.icon
              return (
                <div
                  key={feature.id}
                  className="bg-card rounded-lg p-8 border border-border hover:border-primary transition-colors"
                >
                  <Icon className="w-12 h-12 text-primary mb-4" />
                  <h3 className="text-xl font-bold mb-3 font-serif">{feature.title}</h3>
                  <p className="text-muted-foreground font-serif">{feature.description}</p>
                </div>
              )
            })}
          </div>
        </section>

        {/* Feature Details Section */}
        <section className="px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto py-16">
          <h3 className="font-bold mb-12 font-serif text-4xl">각 기능의 상세 설명</h3>
          <div className="space-y-16">
            {features.map((feature, idx) => {
              const imageUrl =
                feature.imageUrl || `/placeholder.svg?height=256&width=256&query=GFI-Ride-Feature-${feature.id}`

              return (
                <div key={feature.id} className="grid md:grid-cols-2 items-center gap-8">
                  {idx % 2 === 0 ? (
                    <>
                      <div>
                        <h4 className="text-2xl font-bold mb-4 font-serif">
                          {feature.id}. {feature.title}
                        </h4>
                        <p className="text-lg text-muted-foreground mb-6 font-serif">{feature.description}</p>
                        <div className="text-primary font-semibold font-serif">더 알아보기 →</div>
                      </div>
                      <div className="bg-card rounded-lg h-64 flex items-center justify-center border border-border">
                        <img
                          src={imageUrl || "/placeholder.svg"}
                          alt={feature.title}
                          className="rounded-lg w-full h-full object-cover"
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="bg-card rounded-lg h-64 flex items-center justify-center border border-border order-2 md:order-1">
                        <img
                          src={imageUrl || "/placeholder.svg"}
                          alt={feature.title}
                          className="rounded-lg w-full h-full object-cover"
                        />
                      </div>
                      <div className="order-1 md:order-2">
                        <h4 className="text-2xl font-bold mb-4 font-serif">
                          {feature.id}. {feature.title}
                        </h4>
                        <p className="text-lg text-muted-foreground mb-6 font-serif">{feature.description}</p>
                        <div className="text-primary font-semibold font-serif">더 알아보기 →</div>
                      </div>
                    </>
                  )}
                </div>
              )
            })}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
