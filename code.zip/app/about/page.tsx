import Header from "@/components/header"
import Footer from "@/components/footer"

export default function AboutGFIRide() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-24">
        {/* Hero Section (유지) */}
        <section className="px-4 sm:px-6 lg:px-8 py-20 max-w-6xl mx-auto">
          <h1 className="text-4xl sm:text-5xl font-bold mb-6 text-balance font-serif">GFI Ride 소개</h1>
          <h2 className="mb-4 text-balance text-primary font-serif text-6xl leading-[1.2] font-semibold">
            <span className="animate-typing inline-block">라이더를 위한, 라이더에 의한,</span>
            <br />
            <span className="animate-typing inline-block animation-delay-300">당신만의 APEX 올인원 라이딩 솔루션.</span>
          </h2>
          <p className="text-muted-foreground max-w-3xl font-serif py-1 text-2xl font-normal">
            <span className="animate-typing inline-block animation-delay-500">
              고가 장비의 한계를 넘어, 스마트폰 하나로 펼쳐지는 새로운 라이딩의 시작.
            </span>
          </p>
        </section>

        {/* Why GFI Ride Section (내용 보강 및 수정) */}
        <section className="px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto py-1.5">
          <h3 className="text-3xl font-bold mb-8 font-serif animate-in-left">왜 GFI Ride가 필요할까요?</h3>
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              {/* 수정됨: 이전 대화 내용 반영 */}
              <p className="text-lg text-muted-foreground font-serif font-medium mb-0.5 animate-in-left">
                <span>기존 해외 앱들은 한국 라이더들의 고유한 환경과 니즈를 완벽히 담아내지 못했습니다.</span>
                <br />
                <br />
                <span className="animation-delay-100">
                  GFI Ride는 이러한 한계를 넘어, 당신의 라이딩을 최적화된 경험으로 이끌기 위해 탄생했습니다.
                </span>
                <br />
                <br />
              </p>

              {/* 보강됨: 단순 텍스트 리스트에서 설명이 포함된 리스트로 변경 */}
              <ul className="space-y-6 text-foreground">
                <li className="flex gap-3 animate-in-left">
                  <span className="text-primary text-xl mt-1">✓</span>
                  <div>
                    <h5 className="font-semibold text-lg font-serif">한국 라이더에게 최적화된 환경</h5>
                    <p className="text-muted-foreground text-sm font-serif">
                      익숙하지 않은 해외 지도, 소통의 부재 등 한국 라이더가 겪던 불편함을 해소합니다.
                    </p>
                  </div>
                </li>
                <li className="flex gap-3 animate-in-left animation-delay-100">
                  <span className="text-primary text-xl mt-1">✓</span>
                  <div>
                    <h5 className="font-semibold text-lg font-serif">고가 장비 없이 스마트폰 하나로 완벽한 라이딩</h5>
                    <p className="text-muted-foreground text-sm font-serif">
                      수십만 원대 전용 기기 대신, 스마트폰만으로도 전문가 수준의 모든 기능을 누리세요.
                    </p>
                  </div>
                </li>
                <li className="flex gap-3 animate-in-left animation-delay-200">
                  <span className="text-primary text-xl mt-1">✓</span>
                  <div>
                    <h5 className="font-semibold text-lg font-serif">합리적인 비용으로 경험하는 고품질 라이딩</h5>
                    <p className="text-muted-foreground text-sm font-serif">
                      비용 부담 없이 AI 코칭, 소셜, 게이미피케이션 등 최고의 라이딩 경험을 선사합니다.
                    </p>
                  </div>
                </li>
              </ul>
            </div>
            <div className="bg-card rounded-lg h-80 flex items-center justify-center border border-border animate-in-right animation-delay-100">
              <img
                src="/images/design-mode/Gemini_Generated_Image_6sint66sint66sin.png"
                alt="라이딩 환경"
                className="rounded-lg object-cover w-full h-full"
              />
            </div>
          </div>
        </section>

        {/* Vision Section (유지) */}

        {/* Core Values Section (내용 보강) */}
        <section className="px-4 sm:px-6 lg:px-8 py-16 max-w-6xl mx-auto">
          <h3 className="text-3xl font-bold mb-12 font-serif">GFI Ride의 3가지 핵심 가치</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: "혁신적인 기술", desc: "AI 코스 추천 및 맞춤형 기록 분석 등 라이더의 성장을 돕습니다." },
              { title: "강력한 커뮤니티", desc: "함께 달리는 즐거움! 실시간 그룹 라이딩과 소셜 기능으로 소통합니다." },
              {
                title: "짜릿한 동기 부여",
                desc: "게임처럼 즐겁게! 챌린지, 레벨업, 리워드로 강력한 동기를 부여합니다.",
              },
            ].map((value, idx) => (
              <div
                key={idx}
                className={`bg-card rounded-lg p-8 border border-border animate-in-up animation-delay-${idx * 100}`}
              >
                <div className="text-4xl text-primary mb-4 font-serif">0{idx + 1}</div>
                <h4 className="text-xl font-bold mb-3 font-serif">{value.title}</h4>
                <p className="text-muted-foreground font-serif">{value.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Differentiation Section (내용 보강 및 구조 변경) */}
      </main>
      <Footer />
    </div>
  )
}
