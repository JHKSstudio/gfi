import Header from "@/components/header"
import Footer from "@/components/footer"

export default function AboutUs() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-24">
        {/* Header Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-20 max-w-6xl mx-auto">
          <h1 className="text-4xl sm:text-5xl font-bold mb-6 text-balance font-serif">회사 소개</h1>
          <h2 className="text-2xl sm:text-3xl text-primary mb-4 font-semibold text-balance font-serif">
            GFI: Moving Forward, Playing Life.
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl font-serif">
            모빌리티 게이미피케이션으로 세상의 모든 움직임을 재정의합니다.
          </p>
        </section>

        {/* GFI Vision Section */}
        <section className="px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto py-0">
          <h3 className="font-bold mb-8 font-serif text-4xl">GFI의 비전</h3>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-lg text-muted-foreground leading-relaxed font-serif">
                GFI는 단순한 이동을 넘어, 모든 움직임에 즐거움과 의미를 부여하는 모빌리티 게이미피케이션 플랫폼을
                지향합니다.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed mt-6 font-serif font-medium">
                GFI Ride는 그 첫 시작입니다. 자전거라는 순수한 이동 수단에서 얻은 경험을 바탕으로, 앞으로는 즐거운
                드라이브 코스를 추천하고 소통하는 커뮤니티 앱, 그리고 배달 라이더들을 위한 그룹 관리 및 커뮤니케이션 앱
                등, GFI의 즐거운 경험을 모든 &#39;움직임&#39;의 영역으로 확장해 나갈 것입니다.&quot;
              </p>
            </div>
            <div className="bg-card rounded-lg h-80 flex items-center justify-center border border-border">
              <img src="/images/design-mode/21342341234(1).png" alt="GFI 비전" className="rounded-lg" />
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-16 max-w-6xl mx-auto">
          <h3 className="text-3xl font-bold mb-12 font-serif">GFI Team</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "강지형", role: "Co-founder & CEO (기획 담당)", desc: "자전거 열정가이자 기술 혁신가" },
              { name: "조령찬", role: "Co-founder & CEO (마케팅 담당)", desc: "AI 및 모바일 앱 전문가" },
              { name: "윤서희", role: "Designer", desc: "커뮤니티 및 사용자 경험 전문가" },
            ].map((member, idx) => (
              <div key={idx} className="text-center">
                <div className="bg-card rounded-full w-32 h-32 mx-auto mb-6 flex items-center justify-center border border-border">
                  <img
                    src="/images/design-mode/images.png"
                    alt={member.name}
                    className="rounded-full"
                  />
                </div>
                <h4 className="text-xl font-bold mb-2 font-serif">{member.name}</h4>
                <p className="text-primary font-semibold mb-2 font-serif">{member.role}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Future Plans Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-16 bg-card max-w-6xl mx-auto rounded-lg border border-border my-8">
          <h3 className="text-3xl font-bold mb-8 font-serif">GFI의 미래</h3>
          <p className="text-lg text-muted-foreground mb-8 font-serif">
            GFI Ride 이후 더 많은 서비스가 출시될 예정입니다.
          </p>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: "GFI Travel", desc: "여행과 함께하는 게이미피케이션 플랫폼" },
              { name: "GFI Drive", desc: "운전자를 위한 드라이빙 플랫폼" },
              { name: "GFI Riderbase", desc: "배달라이더를 위한 실시간 소통·그룹 관리 플랫폼" },
            ].map((future, idx) => (
              <div key={idx} className="bg-background rounded-lg p-6 border border-border">
                <h4 className="text-lg font-bold mb-2 text-primary font-serif">{future.name}</h4>
                <p className="text-muted-foreground font-serif">{future.desc}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
