"use client"

import { useEffect, useState } from "react"

export default function Testimonials() {
  const testimonials = [
    {
      name: "라이더 김OO",
      text: "GFI Ride 덕분에 라이딩이 달라졌어요!",
      role: "일일 라이더",
    },
    {
      name: "라이더 이OO",
      text: "AI 코칭 기능이 정말 도움이 됩니다.",
      role: "취미 라이더",
    },
    {
      name: "라이더 박OO",
      text: "커뮤니티 기능으로 새로운 친구들을 만났어요!",
      role: "그룹 라이더",
    },
  ]

  const [isVisible, setIsVisible] = useState<{ [key: number]: boolean }>({})

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible((prev) => ({ ...prev, [entry.target.dataset.idx]: true }))
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.1 },
    )

    testimonials.forEach((_, idx) => {
      const ref = document.querySelector(`[data-idx="${idx}"]`)
      if (ref) {
        observer.observe(ref)
      }
    })

    return () => observer.disconnect()
  }, [])

  return (
    <section className="px-4 sm:px-6 lg:px-8 py-20">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-balance font-serif">사용자 후기</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, idx) => {
            return (
              <div
                key={idx}
                data-idx={idx}
                className={`bg-card rounded-lg p-8 border border-border font-serif transition-all duration-700 ${
                  isVisible[idx] ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
                }`}
                style={{
                  transitionDelay: `${idx * 100}ms`,
                }}
              >
                <p className="text-foreground mb-6 italic">"{testimonial.text}"</p>
                <div>
                  <p className="font-bold">{testimonial.name}</p>
                  <p className="text-muted-foreground text-sm">{testimonial.role}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
