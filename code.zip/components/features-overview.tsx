"use client"

import { Zap, Users, Trophy } from "lucide-react"

export default function FeaturesOverview() {
  const features = [
    {
      icon: Zap,
      title: "스마트 AI 코칭",
      description: "맞춤형 코스 추천과 개인화된 건강 코칭",
    },
    {
      icon: Users,
      title: "소셜 라이딩",
      description: "친구들과 함께하는 실시간 그룹 라이딩",
    },
    {
      icon: Trophy,
      title: "즐거운 도전과제",
      description: "게이미피케이션으로 더 재미있는 라이딩",
    },
  ]

  return (
    <section className="px-4 sm:px-6 lg:px-8 py-20 bg-card">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-balance font-serif">
            {"GFI Ride, 당신의 라이딩을 APEX로."}
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, idx) => {
            const Icon = feature.icon
            return (
              <div key={idx} className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-4 font-serif">{feature.title}</h3>
                <p className="text-muted-foreground font-serif">{feature.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
