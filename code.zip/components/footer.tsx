import Link from "next/link"

export default function Footer() {
  return (
    <footer className="bg-card border-t border-border mt-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 font-serif">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-bold text-lg mb-4 font-serif">GFI</h3>
            <p className="text-muted-foreground font-serif font-bold">Your APEX Riding Solution.</p>
          </div>
          <div>
            <h4 className="font-bold mb-4 font-serif">Product</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                <Link href="/features" className="hover:text-primary transition-colors font-serif">
                  주요 기능
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-primary transition-colors font-serif">
                  GFI Ride 소개
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4 font-serif">Company</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                <Link href="/about-us" className="hover:text-primary transition-colors font-serif">
                  회사 소개
                </Link>
              </li>
              <li>
                <Link href="/support" className="hover:text-primary transition-colors font-serif">
                  고객 지원
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4 font-serif">Social</h4>
            <ul className="space-y-2 text-muted-foreground">
              <li>
                <a href="#" className="hover:text-primary transition-colors font-serif">
                  Instagram
                </a>
              </li>
              <li>
                
              </li>
              <li>
                
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border pt-8 mt-8 font-serif">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-muted-foreground text-sm">
            <p className="font-serif">© 2025 GFI. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-primary transition-colors font-serif">
                개인정보처리방침
              </a>
              <a href="#" className="hover:text-primary transition-colors font-serif">
                이용약관
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
