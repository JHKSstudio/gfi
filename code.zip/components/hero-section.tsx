"use client"

import { Download } from "lucide-react"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"

export default function HeroSection() {
  const { ref, isVisible } = useScrollAnimation()

  return (
    <section
      ref={ref}
      className="pt-40 px-4 sm:px-6 lg:px-8 min-h-screen flex items-center bg-gradient-to-br from-background to-card pb-20"
    >
      <div className="max-w-6xl mx-auto w-full">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className={`${isVisible ? "animate-in-left" : ""}`}>
            <h1 className="mb-6 text-balance leading-tight text-7xl font-serif font-bold">
              Your <span className="text-primary font-serif font-black">APEX</span> Riding Solution
            </h1>
            <p className="text-muted-foreground mb-8 text-balance leading-relaxed font-serif font-light text-lg">
              스마트폰 하나로 AI 코칭, 소셜 라이딩, 게이미피케이션을 모두 경험하세요.
            </p>

            {/* Download Buttons */}
            <div className="flex gap-4 flex-wrap">
              <button className="bg-primary text-primary-foreground px-8 py-3 rounded-full font-bold hover:bg-opacity-90 transition-all flex items-center gap-2 font-serif">
                <Download size={20} />
                Google Play
              </button>
              <button className="bg-primary text-primary-foreground px-8 py-3 rounded-full font-bold hover:bg-opacity-90 transition-all flex items-center gap-2 font-serif">
                <Download size={20} />
                App Store
              </button>
            </div>
          </div>

          {/* Right Visual */}
          <div
            className={`h-96 bg-card rounded-lg border border-border flex items-center justify-center ${isVisible ? "animate-in-right" : ""}`}
          >
            <img src="/images/design-mode/123%E3%84%B721321.png.jpeg" alt="GFI Ride App" className="rounded-lg" />
          </div>
        </div>
      </div>
    </section>
  )
}
