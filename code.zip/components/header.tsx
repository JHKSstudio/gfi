"use client"

import Link from "next/link"
import Image from "next/image"
import { useState } from "react"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const navItems = [
    { label: "About GFI Ride", href: "/about" },
    { label: "주요 기능", href: "/features" },
    { label: "회사 소개", href: "/about-us" },
    { label: "고객 지원", href: "/support" },
  ]

  return (
    <header className="fixed top-0 left-0 right-0 bg-background/80 backdrop-blur border-b border-border z-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center">
          <Image src="/images/design-mode/21342341234.png" alt="GFI Ride" width={120} height={40} className="h-auto" priority />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} className="text-foreground hover:text-primary transition-colors font-serif font-medium">
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Download Button */}
        <div className="hidden md:block">
          <button className="bg-primary text-primary-foreground px-6 py-2 rounded-full hover:bg-opacity-90 transition-all font-serif font-bold">
            앱 다운로드
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-foreground" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-card border-t border-border">
          <nav className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 space-y-4">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block text-foreground hover:text-primary transition-colors py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <button className="w-full bg-primary text-primary-foreground px-6 py-2 rounded-full font-bold hover:bg-opacity-90 transition-all mt-4">
              앱 다운로드
            </button>
          </nav>
        </div>
      )}
    </header>
  )
}
